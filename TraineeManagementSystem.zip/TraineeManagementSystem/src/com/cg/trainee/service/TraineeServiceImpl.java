package com.cg.trainee.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.trainee.bean.TraineeBean;
import com.cg.trainee.dao.ITraineeDao;
import com.cg.trainee.exception.TraineeException;

@Service
public class TraineeServiceImpl implements ITraineeService {
	@Autowired
	private ITraineeDao traineeDao;

	@Override
	@Transactional
	public int addTrainee(TraineeBean bean) throws TraineeException {

		return traineeDao.addTrainee(bean);
	}

	@Override
	@Transactional
	public TraineeBean deleteTrainee(int traineeId) throws TraineeException {

		return traineeDao.deleteTrainee(traineeId);
	}

	@Override
	public TraineeBean displayTrainee(int traineeId) throws TraineeException {

		return traineeDao.displayTrainee(traineeId);
	}


	@Override
	@Transactional
	public TraineeBean modifyTrainee(int traineeId, String traineeName,
			String traineeDomain, String traineeLocation)
			throws TraineeException {

		return traineeDao.modifyTrainee(traineeId, traineeName, traineeDomain,
				traineeLocation);
	}

	@Override
	public List<TraineeBean> retrieveAllTrainees() throws TraineeException {
		
		return traineeDao.retrieveAllTrainees();
	}
}
