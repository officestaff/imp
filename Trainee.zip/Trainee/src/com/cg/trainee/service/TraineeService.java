package com.cg.trainee.service;

import java.util.List;

import com.cg.trainee.bean.TraineeBean;
import com.cg.trainee.exception.TraineeException;

public interface TraineeService {

	public void addTrainee(TraineeBean bean) throws TraineeException;
	List<TraineeBean> getAllTrainees() throws TraineeException;
	TraineeBean getTraineeById(int traineeId) throws TraineeException;
	 TraineeBean deleteTraineeById(int traineeId) throws TraineeException;

}
