package com.cg.trainee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.trainee.bean.LoginBean;
import com.cg.trainee.bean.TraineeBean;
import com.cg.trainee.exception.TraineeException;

@Repository
@Transactional
public class TraineeDaoImpl implements TraineeDao {
	
	@PersistenceContext
	EntityManager entityManager;
	
	
	@Override
	public int addTrainee(TraineeBean bean) throws TraineeException {
		
		int id = 0;
		
			try {
				entityManager.persist(bean);
				id = bean.getTraineeId();
				
			} 
			catch (Exception e) {
				throw new TraineeException("unable to persist addTrainee in Dao Layer"
						+ e.getMessage());
			}

			return id;
		
	}

	@Override
	public List<TraineeBean> getAllTrainees() throws TraineeException {
		
		List<TraineeBean> trainees = null;
		try
		{
		String jpql = "SELECT trainee FROM TraineeBean trainee";
		TypedQuery<TraineeBean> query = entityManager.createQuery(jpql, TraineeBean.class);
		trainees = query.getResultList();
		
		}
	catch(Exception ex)
		{
		throw new TraineeException("Unable to get all trainne in dao Layer" +ex.getMessage());
		}
	
	return trainees;
}

	@Override
	public TraineeBean getTraineeById(int traineeId) throws TraineeException {
		
		TraineeBean bean = entityManager.find(TraineeBean.class, traineeId);

		return bean;
	
		
	}

	@Override

	public TraineeBean deleteTraineeById(int traineeId) throws TraineeException {
		
		TraineeBean bean = entityManager.find(TraineeBean.class, traineeId);
			if (bean==null)
			{			
				throw new TraineeException("Unable to delete trainee in dao Layer");
			}
			else
			{
				entityManager.remove(bean);
			}
		return bean;
	}


	@Override
	public TraineeBean modifyTrainee(int traineeId, String traineeName,
			String traineeDomain, String traineeLocation)
			throws TraineeException {
		
		TraineeBean bean;
		try {
			bean = entityManager.find(TraineeBean.class, traineeId);
			bean.setTraineeName(traineeName);
			bean.setTraineeDomain(traineeDomain);
			bean.setTraineeLocation(traineeLocation);
			entityManager.merge(bean);
		} catch (Exception e) {
			throw new TraineeException("Not updated in dao layer"
					+ e.getMessage());
		}

		return bean;
		
	}

	@Override
	public int login(LoginBean login) throws TraineeException {
		// TODO Auto-generated method stub
		String jpql="select login from LoginBean login where login.username=:username and login.password=:password";
		TypedQuery<LoginBean>query=entityManager.createQuery(jpql,LoginBean.class);
		query.setParameter("username", login.getUsername());
		query.setParameter("password", login.getPassword());
		
		try {
			
		LoginBean bean=query.getSingleResult();
		}
		catch(Exception ex)
		{
		throw new TraineeException(ex.getMessage());
		}
		return 1;
	}
		
	}

	

