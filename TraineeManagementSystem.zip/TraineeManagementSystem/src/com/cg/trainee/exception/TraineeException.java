package com.cg.trainee.exception;

public class TraineeException extends Exception{
	public TraineeException() {
		super();
	}	
	
	public TraineeException(String message) {
		super (message);
	}
}
