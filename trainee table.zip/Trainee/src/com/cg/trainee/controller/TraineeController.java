package com.cg.trainee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.trainee.bean.LoginBean;
import com.cg.trainee.bean.TraineeBean;
import com.cg.trainee.exception.TraineeException;
import com.cg.trainee.service.TraineeService;

@Controller
public class TraineeController {
	
	@Autowired                           
	TraineeService traineeService;
	
	@RequestMapping("/")
	public ModelAndView Home() {
		
		ModelAndView mv = new ModelAndView("home");
		return mv;
	}
		
	/*@RequestMapping(value="/display",method=RequestMethod.POST)
	public ModelAndView verifyLogin(@RequestParam String username,@RequestParam String password)	{
		ModelAndView mv = null;
		
		try{
			if(username.equals("vishanth")&& password.equals("vish3449"))
			{
				mv = new ModelAndView("display");
			}
			else
			{
				mv = new ModelAndView("home");
			}
			
		}
		catch(Exception e){
			
			mv = new ModelAndView("home");
			
		}
		return mv;
		
	}
	*/
	/*@RequestMapping("/add")
	public ModelAndView showadd(){
		ModelAndView mv=null;

		
		 mv=new ModelAndView("addTrainee");
		 mv.addObject("trainee",new TraineeBean());
		
		 return mv;
	}
	*/
	/*@RequestMapping(value="/addTrainee",method=RequestMethod.POST)
	public ModelAndView Add(@ModelAttribute("trainee") TraineeBean trainee){
		ModelAndView mv=null;
		try{
			traineeService.addTrainee(trainee);
			mv=new ModelAndView("addTrainee");
			mv.addObject("trainee",new TraineeBean());
		}
		catch(Exception ex){
			mv= new ModelAndView("error");
			mv.addObject("exception","An Error Occured"+ex.getMessage());
		}
		return mv;
		
	}
	
	@RequestMapping("/Add")
	public ModelAndView showadd(){
		ModelAndView mv=null;
	
		 mv=new ModelAndView("success");
		 return mv;

}
*/
	@RequestMapping("/addTrainee")
	public String showAddPage()
	{
		return "addTrainee";
	}

	@RequestMapping(value="/add",method=RequestMethod.POST)
	public ModelAndView Add(@ModelAttribute("trainee") TraineeBean trainee){
		
		ModelAndView mv=null;
		try {
			traineeService.addTrainee(trainee);
			mv = new ModelAndView("success","trainee",trainee);
			
			
		} catch (TraineeException e) {
			mv= new ModelAndView("error");
			mv.addObject("exception","An Error Occured"+e.getMessage());
		}
		
		return mv;
	}
	
	@RequestMapping("/retrieveAllTrainees")
	public ModelAndView showHome()
	{
		ModelAndView mv = null;
		try 
		{
			List<TraineeBean> trainee = traineeService.getAllTrainees();
			mv = new ModelAndView("reterivealltrainee","trainee",trainee);
		} 
		catch (TraineeException e)
		{
			mv = new ModelAndView("error");
			mv.addObject("exception", "An Error Occured "+e.getMessage());
		}
		return mv;
	}
	
	@RequestMapping("/retrieveTrainee")
	public String showTraineeByIdPage()
	{
		return "reterivetrainee";
	}
	
	@RequestMapping(value="/retrieveById",method=RequestMethod.POST)
	public ModelAndView showTraineeById(@ModelAttribute("trainee") TraineeBean bean)
	{
		ModelAndView mv = null;
		
		try {
			TraineeBean traineebean = traineeService.getTraineeById(bean.getTraineeId());
			mv = new ModelAndView("reterivetrainee","trainee",traineebean);
		}
		catch (TraineeException e)
		{
			mv = new ModelAndView("error");
			mv.addObject("exception", "An Error Occured "+e.getMessage());
		}
		return mv;
		
	}
	
	@RequestMapping("/deleteTrainee")
	public String deleteTraineeByIdPage()
	{
		return "deletetrainee";
	}
	
	@RequestMapping(value="/deleteById",method=RequestMethod.POST)
	public ModelAndView deleteTraineeById(@ModelAttribute("trainee") TraineeBean bean){
		
		ModelAndView mv = null;
		
		try {
			TraineeBean traineebean = traineeService.getTraineeById(bean.getTraineeId());
			mv = new ModelAndView("deletetrainee","trainee",traineebean);
		} 
		catch (TraineeException e)
		{
			mv = new ModelAndView("error");
			mv.addObject("exception", "An Error Occured "+e.getMessage());
		}
		return mv;
		
	}
	
	@RequestMapping(value="/deleteId",method=RequestMethod.POST)
	public ModelAndView deleteTraineeId(@ModelAttribute("trainee") TraineeBean bean){
		
		ModelAndView mv = null;
		
		try {
			TraineeBean traineebean = traineeService.deleteTraineeById(bean.getTraineeId());
			mv = new ModelAndView("deletesuccess","trainee",traineebean);
		} 
		catch (TraineeException e)
		{
			mv = new ModelAndView("error");
			mv.addObject("exception", "An Error Occured "+e.getMessage());
		}
		return mv;
		
	}
	
	@RequestMapping("/modifyTrainee")
	public String modifyTrainee()
	{
		return "modifytrainee";
	}
	
	@RequestMapping(value="/modify",method=RequestMethod.POST)
	public ModelAndView modify(@ModelAttribute("train") TraineeBean bean){
		
		ModelAndView mv = null;
		try {
			TraineeBean traineebean = traineeService.getTraineeById(bean.getTraineeId());
			mv = new ModelAndView("modifytrainee","trainee",traineebean);
			
		} 
		catch (TraineeException e)
		{
			mv = new ModelAndView("error");
			mv.addObject("exception", "An Error Occured "+e.getMessage());
		}
		return mv;
	}
	
	@RequestMapping(value="/updateTrainee",method=RequestMethod.POST)
	public ModelAndView updateTrainee(@ModelAttribute("train") TraineeBean bean) {
		
		ModelAndView mv = null;
		
		try {
		
			TraineeBean traineebean = traineeService.modifyTrainee(bean.getTraineeId(),bean.getTraineeName(),
					bean.getTraineeDomain(), bean.getTraineeLocation());
			mv = new ModelAndView("modifysuccess","trainee",traineebean);
		} 
		
		catch (TraineeException e)
		{
			mv = new ModelAndView("error");
			mv.addObject("exception", "An Error Occured "+e.getMessage());
		}
		return mv;
		
	}
	
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public ModelAndView LoginForm(@ModelAttribute("login") LoginBean login)
	{
		ModelAndView mv=null;
		mv=new ModelAndView("display");
		
		try {
			int trainees = traineeService.login(login);
			
		} 
		catch (TraineeException e)
		{
			mv = new ModelAndView("error");
			mv.addObject("exception", "An Error Occured "+e.getMessage());
		}
		return mv;
	}
	
	
	@RequestMapping("/displayHome")
	public String returnToHome()
	{
		return "display";
	}
	
	
	}

