package com.cg.trainee.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table(name = "Trainee")
public class TraineeBean {

	@Id
	@Column(name = "ID")
	private int traineeId;
	@NotEmpty(message="Trainee name cannot be empty")
	@Pattern(regexp = "[A-z][a-zA-Z]+",message="Trainee name must contain only alphabets")
	@Column(name = "Name",length=30)
	private String traineeName;
	@Pattern(regexp = "[A-z][a-zA-Z]+",message="Location must contain only alphabets")
	@Column(name = "Location",length=30)
	private String traineeLocation;
	@Column(name = "Domain",length=30)
	private String traineeDomain;
	
	public TraineeBean(){
		super();
	}
	
	public TraineeBean(int id, String name, String location, String domain) {
		super();
		traineeId = id;
		traineeName = name;
		traineeLocation = location;
		traineeDomain = domain;
	}
	
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	
	
	
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public String getTraineeLocation() {
		return traineeLocation;
	}
	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}
	public String getTraineeDomain() {
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}
	public int getTraineeId() {
		// TODO Auto-generated method stub
		return traineeId;
	}
	
}