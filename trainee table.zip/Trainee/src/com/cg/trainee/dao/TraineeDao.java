package com.cg.trainee.dao;


import java.util.List;

import com.cg.trainee.bean.LoginBean;
import com.cg.trainee.bean.TraineeBean;
import com.cg.trainee.exception.TraineeException;

public interface TraineeDao {
	
	public int addTrainee(TraineeBean bean) throws TraineeException;
	
	List<TraineeBean> getAllTrainees() throws TraineeException;
	
	TraineeBean getTraineeById(int traineeId) throws TraineeException;
	
	 TraineeBean deleteTraineeById(int traineeId) throws TraineeException;
	 
	 public TraineeBean modifyTrainee(int traineeId, String traineeName,
				String traineeDomain, String traineeLocation)
				throws TraineeException;

	 int login(LoginBean login) throws TraineeException;
}
