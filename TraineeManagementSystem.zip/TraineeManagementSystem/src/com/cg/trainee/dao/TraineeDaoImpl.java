package com.cg.trainee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.trainee.bean.TraineeBean;
import com.cg.trainee.exception.TraineeException;


@Repository
public class TraineeDaoImpl implements ITraineeDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public int addTrainee(TraineeBean bean) throws TraineeException {
		int id = 0;

		try {
			
			entityManager.persist(bean);
			entityManager.flush();
			id = bean.getTraineeId();
			
		} catch (Exception e) {
			throw new TraineeException("unable to persist in Dao Layer"+ e.getMessage());
		}
		return id;
	}

	@Override
	public TraineeBean deleteTrainee(int traineeId) throws TraineeException {

		System.out.println("traineeId: " + traineeId);
		TraineeBean bean = entityManager.find(TraineeBean.class, traineeId);

		if (bean == null) {
			System.out.println("  delete fail ");
			throw new TraineeException(" Trainee not found ");
		} else {
			System.out.println(" delete success ");
			entityManager.remove(bean);
		}

		return bean;
	}

	
	@Override
	public TraineeBean displayTrainee(int traineeId) throws TraineeException {

		TraineeBean bean = entityManager.find(TraineeBean.class, traineeId);

		return bean;
	}

	@Override
	public TraineeBean modifyTrainee(int traineeId, String traineeName,
			String traineeDomain, String traineeLocation)
			throws TraineeException {

		TraineeBean bean;
		try {
			bean = entityManager.find(TraineeBean.class, traineeId);
			bean.setTraineeName(traineeName);
			bean.setTraineeDomain(traineeDomain);
			bean.setTraineeLocation(traineeLocation);
			entityManager.merge(bean);
		} catch (Exception e) {
			throw new TraineeException("Not updated in dao layer"
					+ e.getMessage());
		}

		return bean;
	}

	@Override
	public List<TraineeBean> retrieveAllTrainees() throws TraineeException {
	
		List<TraineeBean> list = null;
		
		try {
			String jpql="select trainee from TraineeBean trainee";
			TypedQuery<TraineeBean> query = entityManager.createQuery(jpql,TraineeBean.class);
			list= query.getResultList();
		} catch (Exception e) {
			throw new TraineeException("Unable to retrieve all records in dao layer"+e.getMessage());
			
		}
		return list;
	}
}